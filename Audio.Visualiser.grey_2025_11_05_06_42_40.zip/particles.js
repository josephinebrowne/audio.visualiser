// (The Coding Train, 2016)
function Particle() {
    this.pos = createVector(random(width), random(height)); // Initialise the particle's position at a random point in the canvas, and initialise the particle velocity and acceleration vector
    this.vel = createVector(0, 0); 
    this.acc = createVector(0, 0); 
    this.maxspeed = 3; // Maximum particle speed 
    
    this.prevPos = this.pos.copy(); // Create copy of current position and store it as previous position
 
  
  // Update the particle's position and velocity (The Coding Train, 2016)
    this.update = function() {
      this.vel.add(this.acc); // Acceleration
      this.vel.limit(this.maxspeed); // Limit velocity to the maximum speed
      this.pos.add(this.vel); // Update the position by adding the velocity
      this.acc.mult(0); // Reset acceleration to zero
      this.lifetime++; // Increase the particle's lifetime by one frame
      }

    
  // Make particles follow a direction based on the flowfield vector
    this.follow = function(vectors) {
      var x = floor(this.pos.x / scl);
      var y = floor(this.pos.y / scl); // Calculate the column index based on particle's x and y position
      var index = x + y * cols; // Calculate index of vector
      var force = vectors[index]; // Get corresponding force vector from flowfield
      this.applyForce(force); // Apply force to particles  
    }
  
    // Add force to particles acceleration
    this.applyForce = function(force) {
      this.acc.add(force);
    }
    
    this.show = function() {
      stroke(20, 10); // Set greyscale value and alpha
      strokeWeight(2); // Stroke thickness
      line(this.pos.x, this.pos.y, this.prevPos.x, this.prevPos.y); // draw a line from previous position to current position, creating trail effect
      point(this.pos.x, this.pos.y); // Draw a point at the current position of the particle on the canvas
      this.updatePrev(); // Update previous position to current position
    }
    
  // Update previous x and y positions
 this.updatePrev = function() {
    this.prevPos.x = this.pos.x;
    this.prevPos.y = this.pos.y;
 }   

// Check if the particle has gone off the edges of the canvas and wrap it around to the opposite side
this.edges = function() {
  if (this.pos.x > width) {
    this.pos.x = 0; 
    this.updatePrev();
  }
  if (this.pos.x < 0) {
    this.pos.x = width;
    this.updatePrev();
  }
  if (this.pos.y > height) {
    this.pos.y = 0; 
    this.updatePrev();
  }
  if (this.pos.y < 0) {
    this.pos.y = height; 
    this.updatePrev();
  
    }
  }
}
