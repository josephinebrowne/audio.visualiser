// (The Coding Train, 2016)
function Particle() {
    this.pos = createVector(random(width), random(height)); 
  // Initialise the particle's position at a random point in the canvas, and initialise the particle velocity and acceleration vector
    this.vel = createVector(0, 0); 
    this.acc = createVector(0, 0); 
    this.maxspeed = 5; // Set maximum speed
    
    this.prevPos = this.pos.copy(); // Copy current position and store it as the previous position
    
    this.color = color(random(255), random(255), random(255)); // Assign a random color
    

// Update the particle's position and velocity (The Coding Train, 2016)
    this.update = function() { 
        this.vel.add(this.acc); // Acceleration 
        this.vel.limit(this.maxspeed); // Limit velocity to the maximum speed
        this.pos.add(this.vel); // Update the position by adding the velocity
        this.acc.mult(0); // Reset acceleration to zero
        this.lifetime++; // Increase the particle's lifetime by one frame
        
    }
    
   // Make particles follow a direction based on the flowfield vectors
    this.follow = function(vectors) {
        var x = floor(this.pos.x / scl);
        var y = floor(this.pos.y / scl); // Calculate the column index based on the particle's x and y position
        var index = x + y * cols;  
        var force = vectors[index]; // Get corresponding force vector from flowfield
        this.applyForce(force); // Apply force to particles
    }
    
   // Add force to particles acceleration
    this.applyForce = function(force) {
        this.acc.add(force);
    }
    
    this.show = function() {
        stroke(this.color); // Stroke colour based on random colour
        strokeWeight(1); // Stroke thickness
        line(this.pos.x, this.pos.y, this.prevPos.x, this.prevPos.y);  // draw a line from previous position to current position

        this.updatePrev(); // Update previous position to current position
    }
    
  // Update previous x and y positions
    this.updatePrev = function() { 
        this.prevPos.x = this.pos.x;
        this.prevPos.y = this.pos.y;
    }
    
  // Check if the particle has gone off the edges of the canvas and wrap it around to the opposite side
    this.edges = function() {
        if (this.pos.x > width) {
            this.pos.x = 0; 
            this.updatePrev();
        }
        if (this.pos.x < 0) {
            this.pos.x = width;
            this.updatePrev();
        }
        if (this.pos.y > height) {
            this.pos.y = 0; 
            this.updatePrev();
        }
        if (this.pos.y < 0) {
            this.pos.y = height; 
            this.updatePrev();
        }
    }
}