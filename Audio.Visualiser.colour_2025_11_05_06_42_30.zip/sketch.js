var inc = 0.1; 
var scl = 10; 
var cols, rows; 
var zoff = 0; 
var particles = []; 
var flowfield; 
var song; 
var amplitude; 


// Preload to ensure track is loaded before the rest of the code
function preload() {
  song = loadSound ("Mr.Magic.mp3"); 
}


function setup() {
    createCanvas(200, 200);
    cols = floor(width / scl); 
    rows = floor(height / scl); // set colum and row number to height of canvas
    
    flowfield = new Array(cols * rows); 

  amplitude = new p5.Amplitude(); // Amplitude analyser
  song.play(); 

    // Initialise particles
    for (var i = 0; i < 200; i++) { // Change for number of particles
        particles[i] = new Particle();
    }
}

function draw() {
    fill(255, 5); 
    noStroke();
    rect(0, 0, width, height); 

  
    var yoff = 0; 
  for (var y = 0; y < rows; y++) { 
        var xoff = 0;  // Initialise vertical and horizontal off set
        for (var x = 0; x < cols; x++) { // Loop through each column and row in the flowfield  
            
            var index = x + y * cols; // (The Coding Train, 2016)
            var angle = noise(xoff, yoff, zoff) * TWO_PI * 4; // generates a random value based on specified coordinates, (The Coding Train, 2016)
            var v = p5.Vector.fromAngle(angle); // Create new vector from specific angle (The Coding Train, 2016)
            flowfield[index] = v; // Store vector in flowfield array
            v.setMag(1); // Set a vector's magnitude to a specific value
          
            xoff += inc; 
        }
        yoff += inc; 
        zoff += 0.0003; // Increase to add depth
    }
   
  var level = amplitude.getLevel(); // Get audio amplitude level   
  
   // Loop through each particle in the particles array
    for (var i = 0; i < particles.length; i++) {
        particles[i].follow(flowfield); // Make particles follow the flowfield
        particles[i].update(); 
        particles[i].edges();  
        particles[i].show(); 
    }
  
     // Add new particles if under 200
    if (particles.length < 200) {
        particles.push(new Particle());
    }

}